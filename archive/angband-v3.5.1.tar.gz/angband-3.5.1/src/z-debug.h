/* z-debug.h - debugging support */

#ifndef Z_DEBUG_H
#define Z_DEBUG_H

#define notreached assert(0)
#define testonly /* annotation only */

#endif /* !Z_DEBUG_H */
