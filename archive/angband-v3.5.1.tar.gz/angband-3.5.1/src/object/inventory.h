/* object/inventory.h */

#ifndef OBJECT_INVENTORY_H
#define OBJECT_INVENTORY_H

extern s16b inven_carry(struct player *p, struct object *o);

#endif /* !OBJECT_INVENTORY_H */
