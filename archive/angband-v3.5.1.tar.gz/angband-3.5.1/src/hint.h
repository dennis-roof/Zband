#ifndef HINT_H
#define HINT_H

/*
 * A hint.
 */
struct hint {
	char *hint;
	struct hint *next;
};

#endif /* HINT_H */
