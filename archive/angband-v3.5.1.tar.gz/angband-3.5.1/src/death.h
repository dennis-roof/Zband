#ifndef DEATH_H
#define DEATH_H

extern void death_screen(void);

#endif /* !DEATH_H */
