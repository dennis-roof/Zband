/* birth.h */

#ifndef BIRTH_H
#define BIRTH_H

extern void player_generate(struct player *p, const player_sex *s,
                            struct player_race *r, player_class *c);

#endif /* !BIRTH_H */
