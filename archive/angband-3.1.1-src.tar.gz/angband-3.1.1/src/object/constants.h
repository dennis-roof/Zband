#ifndef INCLUDED_OBJECT_CONSTANTS_H
#define INCLUDED_OBJECT_CONSTANTS_H

/* Size of the object flags array */
#define OBJ_FLAG_N	3


#endif /* INCLUDED_OBJECT_CONSTANTS_H */
